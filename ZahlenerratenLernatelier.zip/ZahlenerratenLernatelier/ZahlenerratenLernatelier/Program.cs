﻿using System;
using System.Collections.Generic;
using System.Globalization;

class NumberGuessingGame
{

    
    private int secretNumber;
    private int attempts;

    public NumberGuessingGame()
    {
        Random random = new Random();//Zufallszahl wird abgespeichert als SecretNumber.
        secretNumber = random.Next(1, 100);
        attempts = 0;
    }

    public string Guess(int number) //Töne und Text, je nach Abweichung zur SecretNumber. Die EIngabe wird überprüft.
    {
        attempts++;
        if (number < secretNumber)
        {
            Console.Beep(10000,500);
            return "Die geratene Zahl ist niedriger als die Geheimzahl.";
            
        }
        else if (number > secretNumber)
        {
            Console.Beep(1000,500);
            return "Die geratene Zahl ist größer als die Geheimzahl.";
            
        }
        else
        {
            Console.Beep(3000,500);
            return "Die Geheimzahl wurde erraten.";
        }
    }

    public int GetAttempts() //Versüche zurückgeben
    {
        return attempts;
    }
}

class HighscoreEntry //Name und Versüche holen
{
    public string PlayerName { get; set; }
    public int Attempts { get; set; }
}

class HighscoreList // Hilfe von ChatGPT. Hier wird die Highscoreliste gemacht
{
    private List<HighscoreEntry> highscores;

    public HighscoreList()
    {
        highscores = new List<HighscoreEntry>();
    }

    public void AddEntry(string playerName, int attempts)
    {
        highscores.Add(new HighscoreEntry { PlayerName = playerName, Attempts = attempts });
    }

    public void Display()
    {
        Console.WriteLine("Highscore List:");
        foreach (var entry in highscores)
        {
            Console.WriteLine($"Player: {entry.PlayerName}, Attempts: {entry.Attempts}");
        }
    }
}

class Program //Das Hauptprogramm
{
    static void Main(string[] args)
    {
        
        Console.BackgroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.Black;
        NumberGuessingGame game = new NumberGuessingGame();
        HighscoreList highscores = new HighscoreList();

        Console.WriteLine("Willkommen beim Zahlenspiel!");
        Console.WriteLine("Errate die Geheimzahl zwischen 1 und 100.");

        while (true)
        {
            try 
            {
                Console.Write("Gib deine Vermutung ein: ");
                int guess = Convert.ToInt32(Console.ReadLine());// Hier hat ChatGPT geholfen

                string result = game.Guess(guess);
                Console.WriteLine(result);

                if (result == "Die Geheimzahl wurde erraten.")// Was passiert wenn die Zahl erraten wurde
                {
                    int attempts = game.GetAttempts();
                    Console.WriteLine($"Anzahl der Rateversuche: {attempts}");

                    Console.WriteLine("Gib deinen Namen für die Highscoreliste ein: ");//Highscoreliste wird gemacht
                    string playerName = Console.ReadLine();
                    highscores.AddEntry(playerName, attempts);
                    highscores.Display();
                    break;
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Bitte gib eine gültige Zahl ein."); //Was passiert bei Fehleingaben.
                Console.Beep(5000, 500);
            }
        }
    }
}
